/**
 * Interface describing the contract for working with Device Command data.
 **/
//# sourceMappingURL=commandContract.js.map